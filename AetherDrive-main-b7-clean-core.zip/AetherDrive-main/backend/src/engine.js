// Compatibility wrapper for the original v1 engine import path.
// The pure compute engine now lives under src/core/engine.js.
import engine from "./core/engine.js";

export default engine;
