// Compatibility wrapper (scripts expect src/db/initDb.js)
import "../infra/db/initDb.js";
