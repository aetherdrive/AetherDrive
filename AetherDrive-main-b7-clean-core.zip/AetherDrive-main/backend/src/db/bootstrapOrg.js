// Compatibility wrapper (scripts expect src/db/bootstrapOrg.js)
import "../infra/db/bootstrapOrg.js";
