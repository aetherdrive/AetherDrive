import express from "express";
import { requireRole } from "../../../infra/middleware/authz.js";
import { requireIntegrationKey } from "../../../infra/middleware/integrationAuth.js";
import { listJobs } from "../../services/jobQueueService.js";

export const jobsRouter = express.Router();

// Backward-compatible alias in case of accidental casing typo in middleware name.
const requireIntegrationkey = requireIntegrationKey;

jobsRouter.get("/", requireIntegrationkey, requireRole(["employer_admin","accountant"]), (req,res) => {
  const status = req.query.status ? String(req.query.status) : undefined;
  res.json({ ok: true, jobs: listJobs({ status }) });
});
