export class EnforcementProvider {
  constructor() {
    this.provider = "mock";
    this.version = "1.0";
  }
}
