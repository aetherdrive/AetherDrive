export class PaymentProvider {
  constructor() {
    this.provider = "mock";
    this.version = "1.0";
  }
}
