export class ReportingProvider {
  constructor() {
    this.provider = "mock";
    this.version = "1.0";
  }
}
