// Compatibility entrypoint.
// Keep package.json scripts stable while the codebase is refactored into
// core/domain/infra layers.
import "./infra/http/server.js";
